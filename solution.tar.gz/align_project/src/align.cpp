#include "align.h"
#include <string>
#include <cmath>

using std::string;
using std::cout;
using std::endl;
using std::make_tuple;
using std::tie;
typedef Matrix<std::tuple<double, double, double>> Ican;

Image MSE(Image img1, Image img2, int ch)
{
    int sw_min = 0, sh_min = 0;
    double s_min = 0;
    uint r1 = 0, g1 = 0, b1 = 0, r2 = 0, g2 = 0, b2 = 0;
    
    //x = 0; y = 0
    for(uint i = 20; i < img1.n_rows - 20; i++)
        for(uint j = 20; j < img1.n_cols - 20; j++)
            s_min += (std::get<0>(img1(i, j)) - std::get<0>(img2(i, j))) * (std::get<0>(img1(i, j)) - std::get<0>(img2(i, j)));
    s_min /= ((img1.n_rows - 40)* (img1.n_cols - 40));
    
    //sw < 0
    for(int sw = -15; sw < 0; sw++)
    {
        //sh < 0
        for(int sh = -15; sh < 0; sh++)
        {
            uint s = 0, w = 0, h = 0;
            for(uint i = sw + 15 + 20; i < sw + img1.n_rows - 20; i++)
                for(uint j = sh + 15 + 20; j < sh + img1.n_cols - 20; j++)
                    s += (std::get<0>(img1(i, j)) - std::get<0>(img2(i - sw, j - sh))) * (std::get<0>(img1(i, j)) - std::get<0>(img2(i - sw, j - sh)));
            w = img1.n_cols + sh - 40;
            h = img1.n_rows + sw - 40;
            s /= (w*h);
            if(s < s_min)
            {
                s_min = s;
                sw_min = sw;
                sh_min = sh;
            }
        }   
        //sh > 0
        for(int sh = 1; sh <= 15; sh++)
        {
            uint s = 0, w = 0, h = 0;
            for(uint i = sw + 15; i < sw + img1.n_rows - 20; i++)
                for(uint j = sh + 20; j < img1.n_cols - 20; j++)
                    s += (std::get<0>(img1(i, j)) - std::get<0>(img2(i - sw, j - sh))) * (std::get<0>(img1(i, j)) - std::get<0>(img2(i - sw, j - sh)));
            w = img1.n_cols - sh - 40;
            h = img1.n_rows + sw - 40;
            s /= (w*h);
            if(s < s_min)
            {
                s_min = s;
                sw_min = sw;
                sh_min = sh;
            }
        }        
    }
    
    //sw > 0
    for(int sw = 1; sw <= 15; sw++)
    {
        //sh < 0
        for(int sh = -15; sh < 0; sh++)
        {
            uint s = 0, w = 0, h = 0;
            for(uint i = sw + 20; i < img1.n_rows - 20; i++)
                for(uint j = sh + 15 + 20; j < sh + img1.n_cols - 20; j++)
                    s += (std::get<0>(img1(i, j)) - std::get<0>(img2(i - sw, j - sh))) * (std::get<0>(img1(i, j)) - std::get<0>(img2(i - sw, j - sh)));
            w = img1.n_cols + sh - 40;
            h = img1.n_rows - sw - 40;
            s /= (w*h);
            if(s < s_min)
            {
                s_min = s;
                sw_min = sw;
                sh_min = sh;
            }
        }
        //sh > 0
        for(int sh = 1; sh <= 15; sh++)
        {
            uint s = 0, w = 0, h = 0;
            for(uint i = sw + 20; i < img1.n_rows - 20; i++)
                for(uint j = sh + 20; j < img1.n_cols - 20; j++)
                    s += (std::get<0>(img1(i, j)) - std::get<0>(img2(i - sw, j - sh))) * (std::get<0>(img1(i, j)) - std::get<0>(img2(i - sw, j - sh)));
            w = img1.n_cols - sh - 40;
            h = img1.n_rows - sw - 40;
            s /= (w*h);
            if(s < s_min)
            {
                s_min = s;
                sw_min = sw;
                sh_min = sh;
            }
        }        
    }
   
    if(sw_min < 0)
    {
        if(sh_min < 0)
            for(uint i = 15 + sw_min; i < sw_min + img1.n_rows; i++)
                for(uint j = 15 + sh_min; j < sh_min + img1.n_cols; j++)
                {
                    tie(r1, g1, b1) = img1(i, j);
                    tie(r2, g2, b2) = img2(i - sw_min, j - sh_min);                 
                    switch (ch)
                    { 
                        case 0: r1 = r2;
                                break;
                        case 1: g1 = g2;
                                break;
                        case 2: b1 = b2;
                                break;
                        default: b1 = b2;
                    }                    
                    img1(i, j) = make_tuple(r1, g1, b1);                 
                }
        else
            for(uint i = 15 + sw_min; i < sw_min + img1.n_rows; i++)
                for(uint j = sh_min; j < img1.n_cols; j++)
                {
                    tie(r1, g1, b1) = img1(i, j);
                    tie(r2, g2, b2) = img2(i - sw_min, j - sh_min);
                    switch (ch)
                    { 
                        case 0: r1 = r2;
                                break;
                        case 1: g1 = g2;
                                break;
                        case 2: b1 = b2;
                                break;
                        default: b1 = b2;
                    }
                    img1(i, j) = make_tuple(r1, g1, b1);
                }   
    }
    else
    {
        if(sh_min < 0)
            for(uint i = sw_min; i < img1.n_rows; i++)
                for(uint j = 15 + sh_min; j < sh_min + img1.n_cols; j++)
                {
                    tie(r1, g1, b1) = img1(i, j);
                    tie(r2, g2, b2) = img2(i - sw_min, j - sh_min);
                    switch (ch)
                    { 
                        case 0: r1 = r2;
                                break;
                        case 1: g1 = g2;
                                break;
                        case 2: b1 = b2;
                                break;
                        default: b1 = b2;        
                    }
                    img1(i, j) = make_tuple(r1, g1, b1);
                }  
        else
            for(uint i = sw_min; i < img1.n_rows; i++)
                for(uint j = sh_min; j < img1.n_cols; j++)
                {
                    tie(r1, g1, b1) = img1(i, j);
                    tie(r2, g2, b2) = img2(i - sw_min, j - sh_min);
                    switch (ch)
                    { 
                        case 0: r1 = r2;
                                break;
                        case 1: g1 = g2;
                                break;
                        case 2: b1 = b2;
                                break;
                        default: b1 = b2;          
                    }
                    img1(i, j) = make_tuple(r1, g1, b1);
                }  
    }
    return img1;
}

Image align(Image srcImage, bool isPostprocessing, std::string postprocessingType, double fraction, bool isMirror, 
            bool isInterp, bool isSubpixel, double subScale)
{
    Image cB, cG, cR;
    Image tmp(srcImage.n_rows, srcImage.n_cols);
    
    srcImage = canny(srcImage, 30, 100);
    
    for(uint i = 0; i < srcImage.n_rows; i++)
        for(uint j = 0; j < srcImage.n_cols; j++)
        {
            uint r = 0, g = 0, b = 0;
            tie(r, g, b) = srcImage(i, j);
            tmp(i, j) = make_tuple(r, g, b);
        }
    
    cB = tmp.submatrix(0, 0, tmp.n_rows / 3, tmp.n_cols);
    cG = tmp.submatrix(tmp.n_rows / 3, 0, tmp.n_rows / 3, tmp.n_cols);
    cR = tmp.submatrix(2 * tmp.n_rows / 3, 0, tmp.n_rows / 3, tmp.n_cols);    

    tmp = MSE(cB, cG, 1);
    tmp = MSE(tmp, cR, 0);
    
    return tmp;
}

Ican custcan(Image src_image, Matrix<double> kernel) {
    // Function custom is useful for making concrete linear filtrations
    // like gaussian or sobel. So, we assume that you implement custom
    // and then implement other filtrations using this function.
    // sobel_x and sobel_y are given as an example.
    uint n_kr = 2 * (kernel.n_rows / 2);
    uint n_kc = 2 * (kernel.n_cols / 2);  
    Ican temp2(src_image.n_rows + n_kr, src_image.n_cols + n_kc);
    Image temp(src_image.n_rows + n_kr, src_image.n_cols + n_kc);
    Ican tmp(src_image.n_rows, src_image.n_cols);    
    uint radr = n_kr / 2;
    uint radc = n_kc / 2;    

    //center of temp
    for(uint i = radr; i < temp.n_rows - radr; i++)
        for(uint j = radc; j < temp.n_cols - radc; j++)
        {
            uint r = 0, g = 0, b = 0;
            tie(r, g, b) = src_image(i - radr, j - radc);
            temp(i, j) = make_tuple(r, g, b);
        }
    //border of temp
        //horizontal
    for(uint i = 0; i < radr; i++)
        for(uint j = radc; j < temp.n_cols - radc; j++)
        {
            uint r = 0, g = 0, b = 0;
            tie(r, g, b) = src_image(0, j - radc);
            temp(i, j) = make_tuple(r, g, b);
        }
    for(uint i = temp.n_rows - radr; i < temp.n_rows; i++)    
        for(uint j = radc; j < temp.n_cols - radc; j++)
        {
            uint r = 0, g = 0, b = 0;
            tie(r, g, b) = src_image(src_image.n_rows - 1, j - radc);
            temp(i, j) = make_tuple(r, g, b);
        }    
        //vertical
    for(uint j = 0; j < radc; j++)
        for(uint i = radr; i < temp.n_rows - radr; i++)
        {
            uint r = 0, g = 0, b = 0;
            tie(r, g, b) = src_image(i - radr, 0);
            temp(i, j) = make_tuple(r, g, b);
        }
    for(uint j = temp.n_cols - radc; j < temp.n_cols; j++)        
        for(uint i = radr; i < temp.n_rows - radr; i++)
        {
            uint r = 0, g = 0, b = 0;
            tie(r, g, b) = src_image(i - radr, src_image.n_cols - 1);
            temp(i, j) = make_tuple(r, g, b);
        }
    //angels
    double r = 0, g = 0, b = 0;
    tie(r, g, b) = src_image(0, 0);
    //left_top
    for(uint i = 0; i < radr; i++)
        for(uint j = 0; j < radc; j++)
            temp(i, j) = make_tuple(r, g, b); 
    //right_top
    tie(r, g, b) = src_image(0, src_image.n_cols - 1);   
    for(uint i = 0; i < radr; i++)
        for(uint j = temp.n_cols - radc; j < temp.n_cols; j++)
            temp(i, j) = make_tuple(r, g, b);    
    //left_bottom      
    tie(r, g, b) = src_image(src_image.n_rows - 1, 0);
    for(uint i = temp.n_rows - radr; i < temp.n_rows; i++)
        for(uint j = 0; j < radc; j++)
            temp(i, j) = make_tuple(r, g, b);    
    //right_bottom
    tie(r, g, b) = src_image(src_image.n_rows - 1, src_image.n_cols - 1);
    for(uint i = temp.n_rows - radr; i < temp.n_rows; i++)
        for(uint j = temp.n_cols - radc; j < temp.n_cols; j++)
            temp(i, j) = make_tuple(r, g, b);
    //filter 
    for(uint i = radr; i < temp.n_rows - radr; i++)
        for(uint j = radc; j < temp.n_cols - radc; j++)
        {
            double sr = 0, sg = 0, sb = 0;
            for(uint k1 = 0; k1 < kernel.n_rows; k1++)
                for(uint k2 = 0; k2 < kernel.n_cols; k2++)
                {
                    sr += double(std::get<0>(temp(i - radr + k1, j - radc + k2))) * kernel(k1, k2);
                    sg += double(std::get<1>(temp(i - radr + k1, j - radc + k2))) * kernel(k1, k2);
                    sb += double(std::get<2>(temp(i - radr + k1, j - radc + k2))) * kernel(k1, k2);
                    tie(r, g, b) = temp(i - radr + k1, j - radc + k2);
                }
            temp2(i, j) = make_tuple(sr, sg, sb);
        } 
    
    for(uint i = radr; i < temp.n_rows - radr; i++)
        for(uint j = radc; j < temp.n_cols - radc; j++)
        {
            tie(r, g, b) = temp2(i, j);
            tmp(i - radr, j - radc) = make_tuple(r, g, b);
        }
    return tmp;
}

Image sobel_x(Image src_image) {
    Matrix<double> kernel = {{-1, 0, 1},
                             {-2, 0, 2},
                             {-1, 0, 1}};
    return custom(src_image, kernel);
}

Ican IX(Image src_image)
{
    Matrix<double> kernel = {{-1.0, 0.0, 1.0},
                             {-2.0, 0.0, 2.0},
                             {-1.0, 0.0, 1.0}};
    return custcan(src_image, kernel);   
}

Image sobel_y(Image src_image) {
    Matrix<double> kernel = {{ 1,  2,  1},
                             { 0,  0,  0},
                             {-1, -2, -1}};
    return custom(src_image, kernel);
}

Ican IY(Image src_image) {
    Matrix<double> kernel = {{ 1.0,  2.0,  1.0},
                             { 0.0,  0.0,  0.0},
                             {-1.0, -2.0, -1.0}};
    return custcan(src_image, kernel);
}

Image unsharp(Image src_image) {
    Matrix<double> kernel = {{-1.0/6, -2.0/3, -1.0/6},
                             {-2.0/3, 13.0/3, -2.0/3},
                             {-1.0/6, -2.0/3, -1.0/6}};
    src_image = custom(src_image, kernel);
    return src_image;
}

double Y(uint R, uint G, uint B)
{
    return 0.2125 * R + 0.7154 * G + 0.0721 * B;
}

Image gray_world(Image src_image) {
    double sr = 0, sg = 0, sb = 0, s = 0;
    for(uint i = 0; i < src_image.n_rows; i++)
        for(uint j = 0; j < src_image.n_cols; j++)
        {
            sr += std::get<0>(src_image(i, j));
            sg += std::get<1>(src_image(i, j));
            sb += std::get<2>(src_image(i, j));
        }
    uint size = src_image.n_rows * src_image.n_cols;
    sr /= size;
    sg /= size;
    sb /= size; 
    s = (sr + sg + sb) / 3;
    for(uint i = 0; i < src_image.n_rows; i++)
        for(uint j = 0; j < src_image.n_cols; j++)
        {
            std::get<0>(src_image(i, j)) *= (s / sr);
            std::get<1>(src_image(i, j)) *= (s / sg);
            std::get<2>(src_image(i, j)) *= (s / sb);
        }
    return src_image;
}

Image resize(Image src_image, double scale) {
    return src_image;
}

Image custom(Image src_image, Matrix<double> kernel) {
    // Function custom is useful for making concrete linear filtrations
    // like gaussian or sobel. So, we assume that you implement custom
    // and then implement other filtrations using this function.
    // sobel_x and sobel_y are given as an example.
    
    //WITH_MIRROR
    uint n_kr = 2 * (kernel.n_rows / 2);
    uint n_kc = 2 * (kernel.n_cols / 2);  
    Image temp(src_image.n_rows + n_kr, src_image.n_cols + n_kc);
    Image tmp(src_image.n_rows, src_image.n_cols);  
    uint radr = n_kr / 2;
    uint radc = n_kc / 2;    
    double div = 0;
    for(uint i = 0; i < kernel.n_rows; i++)
        for(uint j = 0; j < kernel.n_cols; j++)
            div += kernel(i, j);
    //center of temp
    for(uint i = radr; i < temp.n_rows - radr; i++)
        for(uint j = radc; j < temp.n_cols - radc; j++)
        {
            uint r = 0, g = 0, b = 0;
            tie(r, g, b) = src_image(i - radr, j - radc);
            temp(i, j) = make_tuple(r, g, b);
        }
    //border of temp
        //horizontal
    for(uint i = 0; i < radr; i++)
        for(uint j = radc; j < temp.n_cols - radc; j++)
        {
            uint r = 0, g = 0, b = 0;
            tie(r, g, b) = src_image(radr - i - 1, j - radc);
            temp(i, j) = make_tuple(r, g, b);
        }
    for(uint i = temp.n_rows - radr; i < temp.n_rows; i++)    
        for(uint j = radc; j < temp.n_cols - radc; j++)
        {
            uint r = 0, g = 0, b = 0;
            uint l = i - (temp.n_rows - radr);
            tie(r, g, b) = src_image(src_image.n_rows - 1 - l, j - radc);
            temp(i, j) = make_tuple(r, g, b);
        }    
        //vertical
    for(uint j = 0; j < radc; j++)
        for(uint i = radr; i < temp.n_rows - radr; i++)
        {
            uint r = 0, g = 0, b = 0;
            tie(r, g, b) = src_image(i - radr, radc - j - 1);
            temp(i, j) = make_tuple(r, g, b);
        }
    for(uint j = temp.n_cols - radc; j < temp.n_cols; j++)        
        for(uint i = radr; i < temp.n_rows - radr; i++)
        {
            uint r = 0, g = 0, b = 0;
            uint l = j - (temp.n_cols - radc);
            tie(r, g, b) = src_image(i - radr, src_image.n_cols - 1 - l);
            temp(i, j) = make_tuple(r, g, b);
        }
    //angels
    double r = 0, g = 0, b = 0;
    
    //left_top
    for(uint i = 0; i < radr; i++)
        for(uint j = 0; j < radc; j++)
        {
            tie(r, g, b) = src_image(radr - i, radc - j);
            temp(i, j) = make_tuple(r, g, b);
        }
    //right_top
    for(uint i = 0; i < radr; i++)
        for(uint j = temp.n_cols - radc; j < temp.n_cols; j++)
        {
            uint l2 = j - (temp.n_cols - radc);
            tie(r, g, b) = src_image(radr - i, src_image.n_cols - 1 - l2);
            temp(i, j) = make_tuple(r, g, b);  
        }
    //left_bottom        
    for(uint i = temp.n_rows - radr; i < temp.n_rows; i++)
        for(uint j = 0; j < radc; j++)
        {
            uint l1 = i - (temp.n_rows - radr);
            tie(r, g, b) = src_image(src_image.n_rows - 1 - l1, radc - j);
            temp(i, j) = make_tuple(r, g, b);   
        }
    //right_bottom
    for(uint i = temp.n_rows - radr; i < temp.n_rows; i++)
        for(uint j = temp.n_cols - radc; j < temp.n_cols; j++)
        {
            uint l1 = i - (temp.n_rows - radr);
            uint l2 = j - (temp.n_cols - radc);
            tie(r, g, b) = src_image(src_image.n_rows - 1 - l1, src_image.n_cols - 1 - l2);
            temp(i, j) = make_tuple(r, g, b); 
        }
    //filter
    for(uint i = radr; i < temp.n_rows - radr; i++)
        for(uint j = radc; j < temp.n_cols - radc; j++)
        {
            double sr = 0, sg = 0, sb = 0;
            for(uint k1 = 0; k1 < kernel.n_rows; k1++)
                for(uint k2 = 0; k2 < kernel.n_cols; k2++)
                {
                    sr += (std::get<0>(temp(i - radr + k1, j - radc + k2)) * kernel(k1, k2)) / div;
                    sg += (std::get<1>(temp(i - radr + k1, j - radc + k2)) * kernel(k1, k2)) / div;
                    sb += (std::get<2>(temp(i - radr + k1, j - radc + k2)) * kernel(k1, k2)) / div;
                }
            if(sr < 0) sr = 0;
            if(sg < 0) sg = 0;
            if(sb < 0) sb = 0;
            if(sr > 255) sr = 255;
            if(sg > 255) sg = 255;
            if(sb > 255) sb = 255;
            temp(i, j) = make_tuple(uint(sr), uint(sg), uint(sb));
        } 
    for(uint i = radr; i < temp.n_rows - radr; i++)
        for(uint j = radc; j < temp.n_cols - radc; j++)
        {
            tie(r, g, b) = temp(i, j);
            tmp(i - radr, j - radc) = make_tuple(r, g, b);
        }
    return tmp;
}

Image autocontrast(Image src_image, double fraction) {
    uint y_min = 0, y_max = 0;
    double r = 0, g = 0, b = 0;
    double y = 0;
    Image temp(src_image.n_rows, src_image.n_cols);
    uint size_m = src_image.n_rows * src_image.n_cols;
    uint hist[256];
    for(uint i = 0; i < 256; i++)
        hist[i] = 0;
    //hist
    for(uint i = 0; i < src_image.n_rows; i++)
        for(uint j = 0; j < src_image.n_cols; j++)
        {
            tie(r, g, b) = src_image(i, j);
            y = Y(r, g, b);
            hist[uint(y)]++;
        }
    //fraction
    y = 0;
    for(uint i = 0; i < 256; i++)
    {
        y += hist[i];
        if(y >= size_m * fraction)
        {
            y_min = i;
            break;
        }
    }
    y = 0;
    for(int i = 255; i >= 0; i--)
    {
        y += hist[i];
        if(y >= size_m * fraction)
        {
            y_max = i;
            break;
        }
    }
    double y_c = 255.0 / (y_max - y_min);    
    double y_new = 0;
    for(uint i = 0; i < src_image.n_rows; i++)
        for(uint j = 0; j < src_image.n_cols; j++)
        {
            tie(r, g, b) = src_image(i, j);
            y = Y(r, g, b);
            y_new = (y - y_min) * y_c;
            r *= y_new / y;
            g *= y_new / y;
            b *= y_new / y;
            if(r > 255) r = 255;
            if(g > 255) g = 255;
            if(b > 255) b = 255;
            if(r < 0) r = 0;
            if(g < 0) g = 0;
            if(b < 0) b = 0;
            temp(i, j) = make_tuple(uint(r), uint(g), uint(b));
        }
    return temp;
}

Image gaussian(Image src_image, double sigma, int radius)  {
    Matrix<double> kern(2 * radius + 1, 2 * radius + 1);
    double sig = sigma * sigma;
    for(int i = 0; i < radius + 1; i++)
        for(int j = 0; j < radius + 1; j++)
        {
            kern(i, j) = (1 / (2 * M_PI * sig)) * (1 / pow(M_E, (i*i + j*j) / (2 * sig)));
            kern(kern.n_rows - i - 1, j) = kern(i, j);
            kern(i, kern.n_cols - j - 1) = kern(i, j);
            kern(kern.n_rows - i - 1, kern.n_cols - j - 1) = kern(i, j);
        }
    src_image = custom(src_image, kern);
    return src_image;
}

Image gaussian_separable(Image src_image, double sigma, int radius) {
    Matrix<double> kern1(1, 2 * radius + 1);
    Matrix<double> kern2(2 * radius + 1, 1);    

    double sig = sigma * sigma;
    for(int j = 0; j < radius + 1; j++)
    {    
        kern1(0, j) = (1 / (2 * M_PI * sig)) * (1 / pow(M_E, (j*j) / (2 * sig)));
        kern1(0, kern1.n_cols - j - 1) = kern1(0, j);
    }
    for(int i = 0; i < radius + 1; i++)
    {
        kern2(i, 0) = (1 / (2 * M_PI * sig)) * (1 / pow(M_E, (i*i) / (2 * sig)));
        kern2(kern2.n_rows - i - 1, 0) = kern2(i, 0);
    }    
    src_image = custom(src_image, kern1);
    src_image = custom(src_image, kern2);
    return src_image;
}

Image median(Image src_image, int radius) {
    uint r = 0, g = 0, b = 0;
    uint h_r[256], h_g[256], h_b[256];
    Image temp(src_image.n_rows, src_image.n_cols);
    uint sr = 0, sg = 0, sb = 0;
    uint half = (2 * radius + 1)*(2 * radius + 1) / 2;
    for(uint i = radius; i < src_image.n_rows - radius; i++)
        for(uint j = radius; j < src_image.n_cols - radius; j++)
        {
            for(uint l = 0; l < 256; l++)
            {
                h_r[l] = 0;
                h_g[l] = 0;
                h_b[l] = 0;
            }
            for(uint k1 = i - radius; k1 <= i + radius; k1++)
                for(uint k2 = j - radius; k2 <= j + radius; k2++)
                {
                    tie(r, g, b) = src_image(k1, k2);
                    h_r[r]++;
                    h_g[g]++;
                    h_b[b]++;
                    sr = 0;
                    sg = 0;
                    sb = 0;
                    for(uint l = 0; l < 256; l++)
                    {
                        sr += h_r[l];
                        if(sr >= half)
                        {
                            r = l;
                            break;
                        }
                    }
                    for(uint l = 0; l < 256; l++)
                    {
                        sg += h_g[l];
                        if(sg >= half)
                        {
                            g = l;
                            break;
                        }
                    }
                    for(uint l = 0; l < 256; l++)
                    {
                        sb += h_g[l];
                        if(sb >= half)
                        {
                            b = l;
                            break;
                        }
                    }
                    temp(i, j) = make_tuple(r, g, b);
                }
        }
    return temp;
}

Image median_linear(Image src_image, int radius) {
    return src_image;
}

Image median_const(Image src_image, int radius) {
    return src_image;
}

Ican sq(Ican img)
{
    for(uint i = 0; i < img.n_rows; i++)
        for(uint j = 0; j < img.n_cols; j++)
        {
            double r = 0, g = 0, b = 0;
            tie(r, g, b) = img(i, j);
            //cout << r << " " << g << " " << b << "; ";
            img(i, j) = make_tuple(r*r, g*g, b*b);
        }
    return img;
}

Ican IplusIsq(Ican img1, Ican img2)
{
    for(uint i = 0; i < img1.n_rows; i++)
        for(uint j = 0; j < img1.n_cols; j++)
        {
            double r1 = 0, g1 = 0, b1 = 0, r2 = 0, g2 = 0, b2 = 0;
            tie(r1, g1, b1) = img1(i, j);
            tie(r2, g2, b2) = img2(i, j);
            //cout << r1 << " " << r2 << "; ";
            img1(i, j) = make_tuple(sqrt(r1 + r2), sqrt(g1 + g2), sqrt(b1 + b2));
        }
    return img1;
}

Ican atng(Ican img1, Ican img2)
{
    Ican temp(img1.n_rows, img1.n_cols);
    for(uint i = 0; i < img1.n_rows; i++)
        for(uint j = 0; j < img1.n_cols; j++)
        {
            double r1 = 0, g1 = 0, b1 = 0, r2 = 0, g2 = 0, b2 = 0;
            tie(r1, g1, b1) = img1(i, j);
            tie(r2, g2, b2) = img2(i, j);
            //cout << r1 << " " << r2 << "; ";            
            temp(i, j) = make_tuple(atan2(r1, r2), atan2(g1, g2), atan2(b1, b2));
        }
    return temp;
}

int G_max(double t)
{
    double p = M_PI;
    if(t > -p/8 && t <= p/8) return 0;
    else if(t > p/8 && t <= p * 3/8) return 1;
    else if(t > p * 3/8 && t <= p * 5/8) return 2;
    else if(t > p * 5/8 && t <= p * 7/8) return 3;
    else if((t > p * 7/8 ) || (t < -p * 7/8 )) return 0;
    else if(t >= -p * 7/8 && t < -p * 5/8) return 1;
    else if(t > -p * 5/8 && t < -p * 3/8) return 2;
    else if(t > -p * 3/8 && t < -p/8) return 3;
    return 0;
}

Image canny(Image src_image, int threshold1, int threshold2) {
    Image temp(src_image.n_rows, src_image.n_cols);
    Ican I_x(src_image.n_rows, src_image.n_cols);
    Ican I_y(src_image.n_rows, src_image.n_cols);
    Ican G(src_image.n_rows, src_image.n_cols), atn(src_image.n_rows, src_image.n_cols);
    Matrix<uint> S(src_image.n_rows, src_image.n_cols);
    Image tmp(src_image.n_rows, src_image.n_cols);
    for(uint i = 0; i < temp.n_rows; i++)
        for(uint j = 0; j < temp.n_cols; j++)
        {
            uint r = 0, g = 0, b = 0;
            tie(r, g, b) = src_image(i, j);
            tmp(i, j) = make_tuple(r, g, b);
        }
    //1. gauss
    temp = gaussian_separable(src_image, 1.4, 2);
    //2. sobel
    I_x = IX(temp);
    I_y = IY(temp);
    //2. G + atan2
  
    atn = atng(I_y, I_x);
    G = IplusIsq(sq(I_x), sq(I_y));
    
    //3. not-max
    for(uint i = 1; i < temp.n_rows - 1; i++)
        for(uint j = 1; j < temp.n_cols - 1; j++)
        {
            double t = std::get<0>(atn(i, j));

            switch(G_max(t))
            {
                case 0:
                {
                    if(std::get<0>(G(i, j)) <= std::get<0>(G(i, j + 1)) || std::get<0>(G(i, j)) <= std::get<0>(G(i, j - 1)))
                        G(i, j) = make_tuple(0, 0, 0);
                    break;
                }
                case 1:
                {
                    if(std::get<0>(G(i, j)) <= std::get<0>(G(i - 1, j + 1)) || std::get<0>(G(i, j)) <= std::get<0>(G(i + 1, j - 1)))
                        G(i, j) = make_tuple(0, 0, 0);
                    break;
                }
                case 2:
                {
                    if(std::get<0>(G(i, j)) <= std::get<0>(G(i - 1, j)) || std::get<0>(G(i, j)) <= std::get<0>(G(i + 1, j)))
                        G(i, j) = make_tuple(0, 0, 0);
                    break;
                }
                case 3:
                {
                    if(std::get<0>(G(i, j)) <= std::get<0>(G(i - 1, j - 1)) || std::get<0>(G(i, j)) <= std::get<0>(G(i + 1, j + 1)))
                        G(i, j) = make_tuple(0, 0, 0);
                    break;
                }
                default: 
                {
                    if(std::get<0>(G(i, j)) <= std::get<0>(G(i, j + 1)) || std::get<0>(G(i, j)) <= std::get<0>(G(i, j - 1)))
                        G(i, j) = make_tuple(0, 0, 0);
                    break;
                }
            }
        }
    //4.  
    
    //NUMBER_FOUR

    for(uint i = 0; i < temp.n_rows; i++)
        for(uint j = 0; j < temp.n_cols; j++)
        {
            if(std::get<0>(G(i, j)) < threshold1) S(i, j) = 0;
            else if(std::get<0>(G(i, j)) > threshold2) S(i, j) = 1;
            else if(std::get<0>(G(i, j)) >= threshold1 && std::get<0>(G(i, j)) <= threshold2 && S(i, j) != 1) S(i, j) = 2;
        }
        
    //5.
    
    
    for(uint i = 0; i < temp.n_rows; i++)
        for(uint j = 0; j < temp.n_cols; j++)
            if(S(i, j) == 0) temp(i, j) = make_tuple(0, 0, 0);
            
            
    //cat        
    uint h = (src_image.n_cols / 100) * 5;
    uint w = (src_image.n_rows / 100) * 5;
    uint k1 = 0, k2 = 0, k3 = 0, k4 = 0;
    uint p_max = 0;
    for(uint i = 0; i <= w; i++)
    {
        uint p = 0;
        for(uint j = 0; j < temp.n_cols; j++)
        {
            uint r = 0, g = 0, b = 0;
            tie(r, g, b) = temp(i, j);
            if(r != 0 || g != 0 || b != 0) p++;
        }
        if(p >= p_max)
        {
            p_max = p;
            k1 = i;
        }
    }
    p_max = 0;
    for(uint i = temp.n_rows - w; i < temp.n_rows; i++)
    {
        uint p = 0;
        for(uint j = 0; j < temp.n_cols; j++)
        {
            uint r = 0, g = 0, b = 0;
            tie(r, g, b) = temp(i, j);
            if(r != 0 || g != 0 || b != 0) p++;
        }
        if(p > p_max)
        {
            p_max = p;
            k3 = i;
        }
    }
    p_max = 0;
    for(uint j = 0; j <= h; j++)
    {
        uint p = 0;
        for(uint i = 0; i < temp.n_rows; i++)
        {
            uint r = 0, g = 0, b = 0;
            tie(r, g, b) = temp(i, j);
            if(r != 0 || g != 0 || b != 0) p++;
        }
        if(p >= p_max)
        {
            p_max = p;
            k2 = j;
        }
    }
    p_max = 0;
    for(uint j = temp.n_cols - h; j < temp.n_cols; j++)
    {
        uint p = 0;
        for(uint i = 0; i < temp.n_rows; i++)
        {
            uint r = 0, g = 0, b = 0;
            tie(r, g, b) = temp(i, j);
            if(r != 0 || g != 0 || b != 0) p++;
        }
        if(p >= p_max)
        {
            p_max = p;
            k4 = j;
        }
    }
    tmp = tmp.submatrix(k1, k2, k3 - k1, k4 - k2);
    
    return tmp;
}
