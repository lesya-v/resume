#include <iostream>
#include <cmath>
#include <ctime>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <stack>
#include <vector>
#include <algorithm>

using namespace std;

#define INT_MAX 2147483647
#define INT_MIN (-INT_MAX-1)

#define NIL     -1

double t = RAND_MAX;

struct point {	double x;	double y; }; //about point
bool operator==(point &p1, point &p2)
{
   return p1.x == p2.x && p1.y == p2.y;
}
bool operator>(point &p1, point &p2)
{
   return p1.x > p2.x || p1.y > p2.y;
}
bool operator>(point &p1, const point &p2)
{
   return p1.x > p2.x || p1.y > p2.y;
}

bool operator<=(point &p1, point &p2)
{
   return p1.x <= p2.x || p1.y <= p2.y;
}
bool operator<=(point &p1, const point &p2)
{
   return p1.x <= p2.x || p1.y <= p2.y;
}

ostream &operator<<(ostream& os, const point& p)
{
    os << "(" << p.x << ';' << p.y << ")";
    return os;
}

struct cell {	point left_bot;	point right_top; double weight; }; //cell
bool operator!=(cell &c1, cell &c2)
{
   return c1.left_bot.x != c2.left_bot.x || c1.right_top.x != c2.right_top.x ||
           c1.left_bot.y != c2.left_bot.y || c1.right_top.y != c2.right_top.y;
}
bool operator==(cell &c1, cell &c2)
{
   return c1.left_bot.x == c2.left_bot.x && c1.right_top.x == c2.right_top.x &&
           c1.left_bot.y == c2.left_bot.y && c1.right_top.y == c2.right_top.y;
}
bool operator==(const cell &c1, const cell &c2)
{
   return c1.left_bot.x == c2.left_bot.x && c1.right_top.x == c2.right_top.x &&
           c1.left_bot.y == c2.left_bot.y && c1.right_top.y == c2.right_top.y;
}
bool operator<(const cell &c1, const cell &c2)
{
    point cen1 = {(c1.left_bot.x + c1.right_top.x) / 2, (c1.left_bot.y + c1.right_top.y) / 2};
    point cen2 = {(c2.left_bot.x + c2.right_top.x) / 2, (c2.left_bot.y + c2.right_top.y) / 2};
   return (cen1.x < cen2.x) || (cen1.y < cen2.y);
}

ostream &operator<<(ostream& os, const cell& c)
{
    os << "{"<< c.left_bot << " " << c.right_top << "} " << c.weight;
    return os;
}

//weight of cell
double wei(cell &c)
{
    double x = (c.right_top.x - c.left_bot.x) / 2;
    double y = (c.right_top.y - c.left_bot.y) / 2;
    x += c.left_bot.x;
    y += c.left_bot.y;
    return pow(x, 2.0) - pow(y, 2.0);
    //return y;
    //return 1;
    //return x + y;
}

//ссылки:
//описание
//код


//new_point - from cell to smth
point target_point(double x, double y)
{
    double a = 1.35;
    double f_x = x + y + a*x*(1 - x*x);
    //double f_x = 1 - 1.4*x*x + 0.3*y;
    //double f_y = x;
    double f_y = y + a*x*(1 - x*x);
    //double f_x = y;
    //double f_y = x;

//    double t = 0.4 - 6 / (1 + x*x + y*y);
//    double f_x = 2 - 0.9*(x*cos(t) - y*sin(t));
//    double f_y = 0.9*(x*sin(t) + y*cos(t));

//    a = 2.21;
//    f_x = y;
//    f_y = a*y*(1 - x);

    point p1 = {f_x, f_y};
    return p1;
}

// ////////////////////////////HASH///////////////////////////////////////////

static int getCountsOfDigits(long number) {
   return(number == 0) ? 1 : (int) ceil(log10(abs(number) + 0.5));
  }

namespace std {
template <>
  struct hash<pair<int, int>>
  {
    size_t operator()(const pair<int, int>& i) const
    {
        int b = getCountsOfDigits(i.first + 1) + getCountsOfDigits(i.second + 1);
        int por = pow(10, b);
        int item = ((i.first + 1) * por + (i.second + 1));
        return item;
    }
  };
}

// ////////////////////////////GRAPH///////////////////////////////////////////

class Graph_SI
{
    void new_vertices()
    {
        double h_x, h_y;
        h_x = (just_cells[0].right_top.x - just_cells[0].left_bot.x) / x_div;
        h_y = (just_cells[0].right_top.y - just_cells[0].left_bot.y) / y_div;

        double x1 = just_cells[0].left_bot.x;
        double y1 = just_cells[0].left_bot.y;
        double x2 = just_cells[just_cells.size() - 1].right_top.x;
        double y2 = just_cells[just_cells.size() - 1].right_top.y;

        int num_x = (x2 - x1) / h_x; int num_y = (y2 - y1) / h_y;
        double ar_x = x2 - x1; double ar_y = y2 - y1;

        for(auto& i : just_cells)
        {
            double xi = i.left_bot.x;
            double yi = i.left_bot.y;
            for(int x = 0; x < x_div; x++)
                for(int y = 0; y < y_div; y++)
                {
                    cell new_cell = {{xi + x*h_x, yi + y*h_y}, {xi + (x + 1)*h_x, yi + (y + 1)*h_y}};
                    int px = (new_cell.left_bot.x - x1) / h_x;
                    int py = (new_cell.left_bot.y - y1) / h_y;
                    pair<int,int> new_id = make_pair(px, py);
                    id_cells.emplace(new_id, new_cell);
                    //THAT'S OK. MAYBE...
                }
        }

        for(auto& i : id_cells)
        {
            double xi = i.second.left_bot.x;
            double yi = i.second.left_bot.y;

            set<pair<int,int>> dst;
      // RANDOM POINTS
            for(int p = 0; p < 100; p++)
            {
                double new_x = h_x * (rand() / t) + xi;//r * h_x + x * h_x;
                double new_y = h_y * (rand() / t) + yi;

                point new_point = target_point(new_x, new_y);

                int p1 = (new_point.x / h_x); int p2 = (new_point.y / h_y);
                double p_x = p1 * (h_x) + x1; double p_y = p2 * h_y + y1;

                point new_p1 = {p_x, p_y}; point new_p2 = {p_x + h_x, p_y + h_y};
                cell this_cell = {new_p1, new_p2};

                //cout << new_point << " is: " << this_cell << endl;
                //NOW It's right (are U sure?)

                pair<int,int> ident = make_pair((p_x - x1) / h_x, (p_y - y1) / h_y);

                //cout << ident.first << " " << ident.second << " = " << this_cell << endl;
                //All, what is unreal is absent

                if(id_cells.end() != id_cells.find(ident))
                    dst.emplace(ident);

                //+
            }
            if(!dst.empty()) vertices.emplace(i.first, dst);
        }
    }

public:
    vector<cell> just_cells;
    unordered_map<pair<int,int>, set<pair<int,int>>> vertices;
    unordered_map<pair<int,int>, cell> id_cells;
    int x_div, y_div;

    Graph_SI(vector<cell> &cs, int d_x, int d_y)
    {
        this->just_cells = cs;
        this->x_div = d_x;
        this->y_div = d_y;
        new_vertices();
    }

    Graph_SI()
    {
        cell c = {{-1.5, -1.5}, {1.5, 1.5}};
        vector<cell> cs;
        cs.push_back(c);
        just_cells = cs;
        x_div = 1000;
        y_div = 1000;
        //new_vertices();
    }

    Graph_SI(vector<cell> jc, unordered_map<pair<int,int>, set<pair<int,int>>> v, unordered_map<pair<int,int>, cell> id)
    {
        just_cells = jc;
        vertices = v;
        id_cells = id;
    }

    Graph_SI& operator=(const Graph_SI& right)
    {
        if (this == &right)
            return *this;
        just_cells = right.just_cells;
        vertices = right.vertices;
        id_cells = right.id_cells;
        x_div = right.x_div; y_div = right.y_div;
        return *this;
    }

    void vert_w()
    {
        for(auto& i : vertices)
        {
            (*id_cells.find(i.first)).second.weight = wei((*id_cells.find(i.first)).second);
        }
    }

    unordered_map<pair<int,int>,double> cut(unordered_map<pair<int,int>, set<pair<int,int>>> v)
    {
        unordered_map<pair<int,int>,double> cut_id;
        for(auto& i : v)
            cut_id.emplace(make_pair(i.first, (*id_cells.find(i.first)).second.weight));

        return cut_id;
    }

    void print_verts()
    {
        for(auto& i : vertices)
        {
            cout << i.first.first << " " << i.first.second << ": ";// << endl;
            for(auto& j : i.second)
                cout << "(" << j.first << " " << j.second << ") ";
            cout << endl;
        }
    }
    int count_edges()
    {
        int count = 0;
        for(auto& i : vertices)
            for(auto& j : i.second)
                count++;
        return count;
    }
};


// ////////////////////////////TARJAN////////////////////////////////////////

class SCT
{
public:
    int time, scnt;
    unordered_map<pair<int,int>, set<pair<int,int>>> vertex;
    map<pair<int,int>,int> lowlink;
    map<pair<int,int>, bool> used;
    stack<pair<int,int>> S;
    map<int, vector<pair<int,int>>> components;

    void dfs(pair<int,int> u)
    {
        lowlink[u] = time++;
        used[u] = true;
        S.push(u);
        bool isRoot = true;

        for(auto& v : vertex[u])
        {
            if(!used[v]) dfs(v);
            if(lowlink[u] > lowlink[v])
            {
                lowlink[u] = lowlink[v];
                isRoot = false;
            }
        }

        if(isRoot)
        {
            vector<pair<int,int>> component;

            while(true)
            {
                pair<int,int> k = S.top();
                S.pop();
                component.push_back(k);
                lowlink[k] = INT_MAX;
                if(k == u) break;
            }
            components[scnt] = component;
            scnt++;
        }
    }

    map<int, vector<pair<int,int>>> scc()
    {
        for(auto& i : vertex)
        {
            lowlink[i.first] = NIL;
            used[i.first] = false;
        }
        time = 0;
        scnt = 0;
        for(auto& u : vertex)
            if(!used[u.first])
                dfs(u.first);
    }

    //AND IT'S WORKING! :D

    SCT(unordered_map<pair<int,int>, set<pair<int,int>>> vertices)
    {
        if(vertices.empty()) return;
        vertex = vertices;
        scc();
    }

    int max_strong()
    {
        int max_id = 0;
        int max_x = 1;
        for(auto& i : components)
            if(i.second.size() > max_x)
            {
                max_x = i.second.size();
                max_id = i.first;
            }
        return max_id;
    }

    int cnt_st(int id)
    {
        return components[id].size();
    }

    vector<pair<int,int>> get_comp_id(int id)
    {
        return components[id];
    }

    void print_id_strongs(int id)
    {
        for(auto& i : components[id])
        {
            cout << i.first << " " << i.second << ": ";

            for(auto& j : vertex[i])
                cout << "(" << j.first << " " << j.second << ") ";
            cout << endl;
        }
    }

    unordered_map<pair<int,int>, set<pair<int,int>>> cut(int id)
    {
        unordered_map<pair<int,int>, set<pair<int,int>>> cut_vert;
        for(auto& i : components[id])
            cut_vert.emplace(*vertex.find(i));

        for(auto& i : cut_vert)
            for(auto& j : cut_vert[i.first])
                if(cut_vert.end() == cut_vert.find(j))
                    cut_vert[i.first].erase(j);

        return cut_vert;
    }

};

vector<cell> cells_from_pairs(vector<pair<int,int>> pairs, Graph_SI &g)
{
    vector<cell> cells;
    for(auto& i : pairs)
        cells.push_back((*g.id_cells.find(i)).second);
    sort(cells.begin(), cells.end());
    return cells;
}

// ////////////////////////////KARP////////////////////////////////////////
class Graph_CS
{
public:
    unordered_map<pair<int,int>, set<pair<int,int>>> edges;
    unordered_map<int,unordered_map<pair<int,int>,double>> dn;
    unordered_map<pair<int,int>, double> v_wei;

    map<int, vector<pair<int,int>>> comp;

//    Graph_CS(Graph_SI g)//, SCT g_ct)
//    {
//        edges = g.vertices;
//        //comp = g_ct.components;
//        for(auto& i : g.vertices)
//        {
//            //double v1_w = g.vert_w(); //это неверная запись, просто есть ф-я в SI
//            double v1_w = wei((*g.id_cells.find(i.first)).second);
//            v_wei.emplace(make_pair(i.first, v1_w));
//        }
//    }

    Graph_CS(unordered_map<pair<int,int>, set<pair<int,int>>> v, unordered_map<pair<int,int>,double> w)
    {
        edges = v;
        v_wei = w;
    }

    void short_recurs(pair<int,int> pred, int k)
    {
        if (k == edges.size() + 1) return;
        for(auto& j : edges[pred])
        {
            double curr_wt = dn[k - 1][pred] + v_wei[pred];
            if(dn[k][j] == (double)INT_MIN)
                dn[k][j] = curr_wt;
            else
                dn[k][j] = min(dn[k][j], curr_wt);
            //int n = k + 1;
            short_recurs(j, k + 1);
        }
    }

    pair<int,int> shortest_path()
    {
        int V = edges.size();

        for(int i = 0; i <= V; i++)
            for(auto& j : edges)
                dn[i][j.first] = (double)INT_MIN;

        pair<int,int> start;
        for(auto& i : edges)
        {
            start = i.first;
            break;
        }

        dn[0][start] = 0.0;

        for(auto& i : edges[start])
        {
            dn[1][i] = v_wei[start];

            //int k = 1; //for k edges;
            //pair<int,int> pred = i;
            short_recurs(i, 2);
        }

        return start;
    }

    double minAvgWeight()
    {
        pair<int,int> start = shortest_path();
        unordered_map<pair<int,int>, double> avg;
        for(auto& i : edges)
            avg[i.first] = (double)INT_MIN;

        int V = edges.size();

        for(auto& i : edges)
        {
            if(dn[V][i.first] != (double)INT_MIN)
            {
                for(int j = 0; j < V; j++)
                    if (dn[j][i.first] != (double)INT_MIN)
                        avg[i.first] = max(avg[i.first], ((double)dn[V][i.first] - dn[j][i.first]) / (V - j));
            }
        }

        double result = avg[start];
        for (auto& i : edges)
            if (avg[i.first] != (double)INT_MIN && avg[i.first] < result)
                result = avg[i.first];

        return result;
    }

};

int main(int argc, char *argv[])
{
    srand(time(0));
    cell c_g1 = {{-1.5, -1.5}, {1.5, 1.5}};
    //cell c_g1 = {{0.0, 0.0}, {1.0, 1.1}};
    //cell c_g1 = {{-3, -3}, {3, 3}};
    vector<cell> c_g1s;
    c_g1s.push_back(c_g1);

    int start = clock();
    //Graph_SI g1(c_g1s, 1000, 1000);
    Graph_SI g1(c_g1s, 1000, 1000);
    cout << endl << "CountV = " << g1.vertices.size()<< " CountE = " << g1.count_edges() << endl;
    int end = clock();
    cout << "time (in sec): " << (end - start) / CLOCKS_PER_SEC << endl;

    start = clock();
    g1.vert_w();
    SCT tar_g1(g1.vertices);
    cout << "CouStrong = " << tar_g1.components.size() << endl;
    end = clock();
    cout << "time (in sec): " << (end - start) / CLOCKS_PER_SEC << endl;

    start = clock();
    int id = tar_g1.max_strong();
//    unordered_map<pair<int,int>, set<pair<int,int>>> cur_e = tar_g1.cut(id);
//    unordered_map<pair<int,int>,double> cur_w = g1.cut(cur_e);
//    Graph_CS cyc(cur_e, cur_w);
//    cout << cyc.minAvgWeight() << endl;
    double minmin = (double)INT_MIN;
    int k = 0;
    for(auto& i : tar_g1.components)
    {
        int id = i.first;
        unordered_map<pair<int,int>, set<pair<int,int>>> cur_e = tar_g1.cut(id);
        unordered_map<pair<int,int>,double> cur_w = g1.cut(cur_e);
        Graph_CS cyc(cur_e, cur_w);
        if(minmin == (double)INT_MIN) minmin = cyc.minAvgWeight();
        else if(minmin > cyc.minAvgWeight() && cyc.minAvgWeight() != (double)INT_MIN) minmin = cyc.minAvgWeight();
        k++;
    }

    //текст, отзыв

    cout << "minAvg = " << minmin << endl;
    end = clock();
    cout << "time (in sec):" << (end - start) / CLOCKS_PER_SEC << endl;

    return 0;
}
