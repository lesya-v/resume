#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#pragma GCC diagnostic ignored "-Wunused-variable"
#pragma GCC diagnostic ignored "-Wunused-parameter"

#include <string>
#include <vector>
#include <fstream>
#include <cassert>
#include <iostream>
#include <cmath>

#include "matrix.h"
#include "classifier.h"
#include "EasyBMP.h"
#include "linear.h"
#include "argvparser.h"

using std::string;
using std::vector;
using std::ifstream;
using std::ofstream;
using std::pair;
using std::make_pair;
using std::cout;
using std::cerr;
using std::endl;
using std::tie;
using std::make_tuple;

//typedef Matrix<std::tuple<double, double, double>> Ican;

using CommandLineProcessing::ArgvParser;

typedef vector<pair<BMP*, int> > TDataSet;
typedef vector<pair<string, int> > TFileList;
typedef vector<pair<vector<float>, int> > TFeatures;


typedef Matrix<std::tuple<uint, uint, uint>> Image;
typedef Matrix<std::tuple<float, float, float>> Ican;

// Load list of files and its labels from 'data_file' and
// stores it in 'file_list'
void LoadFileList(const string& data_file, TFileList* file_list) {
    ifstream stream(data_file.c_str());

    string filename;
    int label;
    
    int char_idx = data_file.size() - 1;
    for (; char_idx >= 0; --char_idx)
        if (data_file[char_idx] == '/' || data_file[char_idx] == '\\')
            break;
    string data_path = data_file.substr(0,char_idx+1);
    
    while(!stream.eof() && !stream.fail()) {
        stream >> filename >> label;
        if (filename.size())
            file_list->push_back(make_pair(data_path + filename, label));
    }

    stream.close();
}

// Load images by list of files 'file_list' and store them in 'data_set'
void LoadImages(const TFileList& file_list, TDataSet* data_set) {
    for (size_t img_idx = 0; img_idx < file_list.size(); ++img_idx) {
            // Create image
        BMP* image = new BMP();
            // Read image from file
        image->ReadFromFile(file_list[img_idx].first.c_str());
            // Add image and it's label to dataset
        data_set->push_back(make_pair(image, file_list[img_idx].second));
    }
}

// Save result of prediction to file
void SavePredictions(const TFileList& file_list,
                     const TLabels& labels, 
                     const string& prediction_file) {
        // Check that list of files and list of labels has equal size 
    assert(file_list.size() == labels.size());
        // Open 'prediction_file' for writing
    ofstream stream(prediction_file.c_str());

        // Write file names and labels to stream
    for (size_t image_idx = 0; image_idx < file_list.size(); ++image_idx)
        stream << file_list[image_idx].first << " " << labels[image_idx] << endl;
    stream.close();
}

// Exatract features from dataset.

Image convert_BMP_to_matrix(BMP* in)
{
    Image res(in->TellHeight(), in->TellWidth());
    for (uint i = 0; i < res.n_rows; ++i) {
        for (uint j = 0; j < res.n_cols; ++j) {
            RGBApixel p = in->GetPixel(j, i);
            res(i, j) = make_tuple(p.Red, p.Green, p.Blue);
        }
    }
    return res;
}

BMP convert_matrix_to_B(Image &im)
{
    BMP out;
    out.SetSize(im.n_cols, im.n_rows);
    uint r, g, b;
    RGBApixel p;
    p.Alpha = 255;
    for (uint i = 0; i < im.n_rows; ++i) {
        for (uint j = 0; j < im.n_cols; ++j) {
            tie(r, g, b) = im(i, j);
            p.Red = r; p.Green = g; p.Blue = b;
            out.SetPixel(j, i, p);
        }
    }
    return out;
}

BMP convert_matrix_to_BC(Ican &im)
{
    BMP out;
    out.SetSize(im.n_cols, im.n_rows);
    uint r, g, b;
    RGBApixel p;
    p.Alpha = 255;
    for (uint i = 0; i < im.n_rows; ++i) {
        for (uint j = 0; j < im.n_cols; ++j) {
            tie(r, g, b) = im(i, j);
            p.Red = r; p.Green = g; p.Blue = b;
            out.SetPixel(j, i, p);
        }
    }
    return out;
}

float Y(uint R, uint G, uint B)
{
    return 0.299 * R + 0.587 * G + 0.114 * B;
}

Image grayscale(Image img)
{
    Image img2(img.n_rows, img.n_cols);
    uint i = 0, j = 0;
    uint r = 0, g = 0, b = 0;
    uint r1 = 0, g1 = 0, b1 = 0;
    for(i = 0; i < img.n_rows; i++)
        for(j = 0; j < img.n_cols; j++)
        {
            tie(r1, g1, b1) = img(i, j);
            r = g = b = Y(r1, g1, b1);
            img2(i, j) = make_tuple(r, g, b);
        }
    return img2;
}

Ican custcan(Image src_image, Matrix<double> kernel) {
    // Function custom is useful for making concrete linear filtrations
    // like gaussian or sobel. So, we assume that you implement custom
    // and then implement other filtrations using this function.
    // sobel_x and sobel_y are given as an example.
    uint n_kr = 2 * (kernel.n_rows / 2);
    uint n_kc = 2 * (kernel.n_cols / 2);  
    Ican temp2(src_image.n_rows + n_kr, src_image.n_cols + n_kc);
    Image temp(src_image.n_rows + n_kr, src_image.n_cols + n_kc);
    Ican tmp(src_image.n_rows, src_image.n_cols);    
    uint radr = n_kr / 2;
    uint radc = n_kc / 2;    

    //center of temp
    for(uint i = radr; i < temp.n_rows - radr; i++)
        for(uint j = radc; j < temp.n_cols - radc; j++)
        {
            uint r = 0, g = 0, b = 0;
            tie(r, g, b) = src_image(i - radr, j - radc);
            temp(i, j) = make_tuple(r, g, b);
        }
    //border of temp
        //horizontal
    for(uint i = 0; i < radr; i++)
        for(uint j = radc; j < temp.n_cols - radc; j++)
        {
            uint r = 0, g = 0, b = 0;
            tie(r, g, b) = src_image(0, j - radc);
            temp(i, j) = make_tuple(r, g, b);
        }
    for(uint i = temp.n_rows - radr; i < temp.n_rows; i++)    
        for(uint j = radc; j < temp.n_cols - radc; j++)
        {
            uint r = 0, g = 0, b = 0;
            tie(r, g, b) = src_image(src_image.n_rows - 1, j - radc);
            temp(i, j) = make_tuple(r, g, b);
        }    
        //vertical
    for(uint j = 0; j < radc; j++)
        for(uint i = radr; i < temp.n_rows - radr; i++)
        {
            uint r = 0, g = 0, b = 0;
            tie(r, g, b) = src_image(i - radr, 0);
            temp(i, j) = make_tuple(r, g, b);
        }
    for(uint j = temp.n_cols - radc; j < temp.n_cols; j++)        
        for(uint i = radr; i < temp.n_rows - radr; i++)
        {
            uint r = 0, g = 0, b = 0;
            tie(r, g, b) = src_image(i - radr, src_image.n_cols - 1);
            temp(i, j) = make_tuple(r, g, b);
        }
    //angels
    float r = 0, g = 0, b = 0;
    tie(r, g, b) = src_image(0, 0);
    //left_top
    for(uint i = 0; i < radr; i++)
        for(uint j = 0; j < radc; j++)
            temp(i, j) = make_tuple(r, g, b); 
    //right_top
    tie(r, g, b) = src_image(0, src_image.n_cols - 1);   
    for(uint i = 0; i < radr; i++)
        for(uint j = temp.n_cols - radc; j < temp.n_cols; j++)
            temp(i, j) = make_tuple(r, g, b);    
    //left_bottom      
    tie(r, g, b) = src_image(src_image.n_rows - 1, 0);
    for(uint i = temp.n_rows - radr; i < temp.n_rows; i++)
        for(uint j = 0; j < radc; j++)
            temp(i, j) = make_tuple(r, g, b);    
    //right_bottom
    tie(r, g, b) = src_image(src_image.n_rows - 1, src_image.n_cols - 1);
    for(uint i = temp.n_rows - radr; i < temp.n_rows; i++)
        for(uint j = temp.n_cols - radc; j < temp.n_cols; j++)
            temp(i, j) = make_tuple(r, g, b);
    //filter 
    for(uint i = radr; i < temp.n_rows - radr; i++)
        for(uint j = radc; j < temp.n_cols - radc; j++)
        {
            float sr = 0, sg = 0, sb = 0;
            for(uint k1 = 0; k1 < kernel.n_rows; k1++)
                for(uint k2 = 0; k2 < kernel.n_cols; k2++)
                {
                    sr += float(std::get<0>(temp(i - radr + k1, j - radc + k2))) * kernel(k1, k2);
                    sg += float(std::get<1>(temp(i - radr + k1, j - radc + k2))) * kernel(k1, k2);
                    sb += float(std::get<2>(temp(i - radr + k1, j - radc + k2))) * kernel(k1, k2);
                    tie(r, g, b) = temp(i - radr + k1, j - radc + k2);
                }
            temp2(i, j) = make_tuple(sr, sg, sb);
        } 
    
    for(uint i = radr; i < temp.n_rows - radr; i++)
        for(uint j = radc; j < temp.n_cols - radc; j++)
        {
            tie(r, g, b) = temp2(i, j);
            tmp(i - radr, j - radc) = make_tuple(r, g, b);
        }
    return tmp;
}

Ican IX(Image src_image)
{
    Matrix<double> kernel = {{-1.0, 0.0, 1.0},
                             {-2.0, 0.0, 2.0},
                             {-1.0, 0.0, 1.0}};
    return custcan(src_image, kernel);   
}

Ican IY(Image src_image) {
    Matrix<double> kernel = {{ 1.0,  2.0,  1.0},
                             { 0.0,  0.0,  0.0},
                             {-1.0, -2.0, -1.0}};                  
    return custcan(src_image, kernel);
}

Ican sq(Ican img)
{
    for(uint i = 0; i < img.n_rows; i++)
        for(uint j = 0; j < img.n_cols; j++)
        {
            float r = 0, g = 0, b = 0;
            tie(r, g, b) = img(i, j);
            //cout << r << " " << g << " " << b << "; ";
            img(i, j) = make_tuple(r*r, g*g, b*b);
        }
    return img;
}

Ican IplusIsq(Ican img1, Ican img2)
{
    for(uint i = 0; i < img1.n_rows; i++)
        for(uint j = 0; j < img1.n_cols; j++)
        {
            float r1 = 0, g1 = 0, b1 = 0, r2 = 0, g2 = 0, b2 = 0;
            tie(r1, g1, b1) = img1(i, j);
            tie(r2, g2, b2) = img2(i, j);
            //cout << r1 << " " << r2 << "; ";
            img1(i, j) = make_tuple(sqrt(r1 + r2), sqrt(g1 + g2), sqrt(b1 + b2));
        }
    return img1;
}

Ican atng(Ican img1, Ican img2)
{
    Ican temp(img1.n_rows, img1.n_cols);
    for(uint i = 0; i < img1.n_rows; i++)
        for(uint j = 0; j < img1.n_cols; j++)
        {
            float r1 = 0, g1 = 0, b1 = 0, r2 = 0, g2 = 0, b2 = 0;
            tie(r1, g1, b1) = img1(i, j);
            tie(r2, g2, b2) = img2(i, j);
            //cout << r1 << " " << r2 << "; ";            
            temp(i, j) = make_tuple(atan2(r1, r2), atan2(g1, g2), atan2(b1, b2));
        }
    return temp;
}

int G_max(double t)
{
    double p = M_PI;
    if(t > -p/8 && t <= p/8) return 0;
    else if(t > p/8 && t <= p * 3/8) return 1;
    else if(t > p * 3/8 && t <= p * 5/8) return 2;
    else if(t > p * 5/8 && t <= p * 7/8) return 3;
    else if((t > p * 7/8 ) || (t < -p * 7/8 )) return 4;
    else if(t >= -p * 7/8 && t < -p * 5/8) return 5;
    else if(t > -p * 5/8 && t < -p * 3/8) return 6;
    else if(t > -p * 3/8 && t < -p/8) return 7;
    return 0;
}

float norm_ev8(float a[8])
{
    float n = 0;
    int i = 0;
    for(i = 0; i < 8; i++)
        n += a[i] * a[i];
    n = sqrt(n);
    return n;
}

int bin_to_dem(int binary[])
{
    int res = 0;
    for(int i = 9; i > 0; i--)
    {
        if(i == 5) continue;
        res += pow(binary[i], i - 1);
    }
    return res;
}

// You should implement this function by yourself =)
void ExtractFeatures(const TDataSet& data_set, TFeatures* features) {
    for (size_t image_idx = 0; image_idx < data_set.size(); ++image_idx) {
        BMP* img_B = data_set[image_idx].first;
        Image img_M = convert_BMP_to_matrix(img_B);
        Image img_gray = grayscale(img_M);
        Ican sobelX = IX(img_gray);
        Ican sobelY = IY(img_gray);
        Ican atn = atng(sobelX, sobelY);
        Ican G = IplusIsq(sq(sobelX), sq(sobelY));
        int i = 0, j = 0, k = 0, ki = 0, kj = 0;
        int sq_r = G.n_rows / 8, sq_c = G.n_cols / 8;
        int lbp_bin[9];
        float a[8][8][8], colors[3][8][8], lbp[8][8][256];
        for(i = 0; i < 8; i++)
            for(j = 0; j < 8; j++)
                for(k = 0; k < 8; k++)
                    a[i][j][k] = 0.0;
                
        for(k = 0; k < 3; k++)
            for(i = 0; i < 8; i++)
                for(j = 0; j < 8; j++)
                    colors[k][i][j] = 0.0;
        
        for(i = 0; i < 8; i++)
            for(j = 0; j < 8; j++)
                for(k = 0; k < 256; k++)
                    lbp[i][j][k] = 0.0;
                
        for(i = 0; i < 9; i++)
            lbp_bin[i] = 0;
                
        for(ki = 1; ki <= 8; ki++)
            for(kj = 1; kj <= 8; kj++)
            {
                float sr = 0, sg = 0, sb = 0;
                for(i = (ki - 1)*sq_r; i < ki*sq_r; i++)
                    for(j = (kj - 1)*sq_c; j < kj*sq_c; j++)
                    {
                        uint r = 0, g = 0, b = 0;
                        tie(r, g, b) = img_M(i, j);
                        sr += float(r);
                        sg += float(g);
                        sb += float(b);
                    }
                sr /= (sq_r * sq_c * 255);
                sg /= (sq_r * sq_c * 255);
                sb /= (sq_r * sq_c * 255);
                colors[0][ki - 1][kj - 1] = sr;
                colors[1][ki - 1][kj - 1] = sg;
                colors[2][ki - 1][kj - 1] = sb;
            }
            
        for(ki = 1; ki <= 8; ki++)
            for(kj = 1; kj <= 8; kj++)
            {
                for(i = (ki - 1)*sq_r; i < ki*sq_r; i++)
                    for(j = (kj - 1)*sq_c; j < kj*sq_c; j++)
                    {
                        int t = G_max(std::get<0>(atn(i, j)));
                        a[ki - 1][kj - 1][t] += std::get<0>(G(i, j));
                    }
            }
            
        for(ki = 1; ki <= 8; ki++)
            for(kj = 1; kj <= 8; kj++)
            {
                for(i = (ki - 1)*sq_r + 1; i < ki*sq_r - 1; i++)
                    for(j = (kj - 1)*sq_c + 1; j < kj*sq_c - 1; j++)
                    {
                        int r = 0;
                        for(int l1 = -1; l1 <= 1; l1++)
                            for(int l2 = -1; l2 <= 1; l2++)
                                if(std::get<0>(img_gray(i, j)) >= std::get<0>(img_gray(i + l1, j + l2))) {lbp_bin[r] = 1; r++;}
                                else {lbp_bin[r] = 0; r++;}
                        lbp[ki - 1][kj - 1][bin_to_dem(lbp_bin) - 1]++;
                    }
            }
        
        for(ki = 0; ki < 8; ki++)
            for(kj = 0; kj < 8; kj++)
            {
                float lbp_norm = 0;
                for(k = 0; k < 256; k++)
                    lbp_norm += lbp[ki][kj][k];
                lbp_norm = sqrt(lbp_norm);
                for(k = 0; k < 256; k++)
                {
                    lbp[ki][kj][k] /= lbp_norm;
                    if(std::isnan(lbp[ki][kj][k])) lbp[ki][kj][k] = 0;
                }
            }
        
        for(ki = 0; ki < 8; ki++)
            for(kj = 0; kj < 8; kj++)
            {
                float mas_norm[8] = {a[ki][kj][0], a[ki][kj][1], a[ki][kj][2], a[ki][kj][3], a[ki][kj][4], a[ki][kj][5], a[ki][kj][6], a[ki][kj][7]};
                float norm = norm_ev8(mas_norm);
                for(k = 0; k < 8; k++)
                {
                    a[ki][kj][k] /= norm;
                    if(std::isnan(a[ki][kj][k])) a[ki][kj][k] = 0;
                }
            }
        vector<float> one_image_features;
        for(ki = 0; ki < 8; ki++)
            for(kj = 0; kj < 8; kj++)
                for(k = 0; k < 8; k++)
                    one_image_features.push_back(a[ki][kj][k]);
        
        for(i = 0; i < 8; i++)
            for(j = 0; j < 8; j++)
                for(k = 0; k < 3; k++)
                    one_image_features.push_back(colors[k][i][j]);
        
        for(i = 0; i < 8; i++)
            for(j = 0; j < 8; j++)
                for(k = 0; k < 256; k++)
                    one_image_features.push_back(lbp[i][j][k]);
    
        features->push_back(make_pair(one_image_features, data_set[image_idx].second));
    }
    
}

// Clear dataset structure
void ClearDataset(TDataSet* data_set) {
        // Delete all images from dataset
    for (size_t image_idx = 0; image_idx < data_set->size(); ++image_idx)
        delete (*data_set)[image_idx].first;
        // Clear dataset
    data_set->clear();
}

// Train SVM classifier using data from 'data_file' and save trained model
// to 'model_file'
void TrainClassifier(const string& data_file, const string& model_file) {
        // List of image file names and its labels
    TFileList file_list;
        // Structure of images and its labels
    TDataSet data_set;
        // Structure of features of images and its labels
    TFeatures features;
        // Model which would be trained
    TModel model;
        // Parameters of classifier
    TClassifierParams params;
    
        // Load list of image file names and its labels
    LoadFileList(data_file, &file_list);
        // Load images
    LoadImages(file_list, &data_set);
        // Extract features from images
    ExtractFeatures(data_set, &features);

        // PLACE YOUR CODE HERE
        // You can change parameters of classifier here
    params.C = 0.01;
    TClassifier classifier(params);
        // Train classifier
    classifier.Train(features, &model);
        // Save model to file
    model.Save(model_file);
        // Clear dataset structure
    ClearDataset(&data_set);
}

// Predict data from 'data_file' using model from 'model_file' and
// save predictions to 'prediction_file'
void PredictData(const string& data_file,
                 const string& model_file,
                 const string& prediction_file) {
        // List of image file names and its labels
    TFileList file_list;
        // Structure of images and its labels
    TDataSet data_set;
        // Structure of features of images and its labels
    TFeatures features;
        // List of image labels
    TLabels labels;

        // Load list of image file names and its labels
    LoadFileList(data_file, &file_list);
        // Load images
    LoadImages(file_list, &data_set);
        // Extract features from images
    ExtractFeatures(data_set, &features);

        // Classifier 
    TClassifier classifier = TClassifier(TClassifierParams());
        // Trained model
    TModel model;
        // Load model from file
    model.Load(model_file);
        // Predict images by its features using 'model' and store predictions
        // to 'labels'
    classifier.Predict(features, model, &labels);

        // Save predictions
    SavePredictions(file_list, labels, prediction_file);
        // Clear dataset structure
    ClearDataset(&data_set);
}

int main(int argc, char** argv) {
    // Command line options parser
    ArgvParser cmd;
        // Description of program
    cmd.setIntroductoryDescription("Machine graphics course, task 2. CMC MSU, 2014.");
        // Add help option
    cmd.setHelpOption("h", "help", "Print this help message");
        // Add other options
    cmd.defineOption("data_set", "File with dataset",
        ArgvParser::OptionRequiresValue | ArgvParser::OptionRequired);
    cmd.defineOption("model", "Path to file to save or load model",
        ArgvParser::OptionRequiresValue | ArgvParser::OptionRequired);
    cmd.defineOption("predicted_labels", "Path to file to save prediction results",
        ArgvParser::OptionRequiresValue);
    cmd.defineOption("train", "Train classifier");
    cmd.defineOption("predict", "Predict dataset");
        
        // Add options aliases
    cmd.defineOptionAlternative("data_set", "d");
    cmd.defineOptionAlternative("model", "m");
    cmd.defineOptionAlternative("predicted_labels", "l");
    cmd.defineOptionAlternative("train", "t");
    cmd.defineOptionAlternative("predict", "p");

        // Parse options
    int result = cmd.parse(argc, argv);

        // Check for errors or help option
    if (result) {
        cout << cmd.parseErrorDescription(result) << endl;
        return result;
    }

        // Get values 
    string data_file = cmd.optionValue("data_set");
    string model_file = cmd.optionValue("model");
    bool train = cmd.foundOption("train");
    bool predict = cmd.foundOption("predict");

        // If we need to train classifier
    if (train)
        TrainClassifier(data_file, model_file);
        // If we need to predict data
    if (predict) {
            // You must declare file to save images
        if (!cmd.foundOption("predicted_labels")) {
            cerr << "Error! Option --predicted_labels not found!" << endl;
            return 1;
        }
            // File to save predictions
        string prediction_file = cmd.optionValue("predicted_labels");
            // Predict data
        PredictData(data_file, model_file, prediction_file);
    }
}
